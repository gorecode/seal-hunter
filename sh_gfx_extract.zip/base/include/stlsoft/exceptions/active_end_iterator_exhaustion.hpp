
#error This file is now obsolete. Instead include stlsoft/error/active_end_iterator_exhaustion.hpp

/* Compatibility
[<[STLSOFT-AUTO:NO-DOCFILELABEL]>]
[<[STLSOFT-AUTO:NO-UNITTEST]>]
*/

/* ///////////////////////////// end of file //////////////////////////// */
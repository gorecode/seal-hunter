
#error This file is now obsolete. Instead include stlsoft/error/unrecoverable.hpp

/* Compatibility
[<[STLSOFT-AUTO:NO-DOCFILELABEL]>]
[<[STLSOFT-AUTO:NO-UNITTEST]>]
*/

/* ///////////////////////////// end of file //////////////////////////// */